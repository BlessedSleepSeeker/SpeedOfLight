#!/bin/sh
printf '\033c\033]0;%s\a' Speed Of Light
base_path="$(dirname "$(realpath "$0")")"
"$base_path/SpeedOfLight_Linux" "$@"
